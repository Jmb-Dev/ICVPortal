﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SAP.Middleware.Connector;
using ProyectoTanner.Models;
using ProyectoTanner.Controllers;

namespace ProyectoTanner.Services
{
    public class InformacionColaborador
    {
        public List<ColaboradresJerarquia> ObjSalida = new List<ColaboradresJerarquia>();
        public List<Tablamensaje> Objmensaje = new List<Tablamensaje>();

        public List<InformacionColaboradores> ObtenerDatos(string RUT,string usuario, string contrasena)
        {
            IRfcTable lt_T_MENSAJE;

            IRfcStructure lt_E_OUTPUT;

            InformacionColaboradores SalidaDatosColab;

            ConexionController conexion = new ConexionController();

            List<InformacionColaboradores> ListaColaborador = new List<InformacionColaboradores>();

            string retorno = "ERROR";

            try
            {
                if (!string.IsNullOrEmpty(usuario) && !string.IsNullOrEmpty(contrasena))
                    retorno = conexion.connectionsSAP(usuario, contrasena);

                if (string.IsNullOrEmpty(retorno))
                {
                    RfcDestination SapRfcDestination = RfcDestinationManager.GetDestination(conexion.connectorConfig);
                    RfcRepository SapRfcRepository = SapRfcDestination.Repository;

                    IRfcFunction BapiGetUser = SapRfcRepository.CreateFunction("ZHR_DAT_MAE");

                    BapiGetUser.SetValue("I_RUT", RUT);

                    BapiGetUser.Invoke(SapRfcDestination);

                    lt_E_OUTPUT = BapiGetUser.GetStructure("E_OUTPUT");

                    SalidaDatosColab = new InformacionColaboradores();
                    SalidaDatosColab.VORNA = lt_E_OUTPUT[0].GetValue().ToString();
                    SalidaDatosColab.NACHN = lt_E_OUTPUT[2].GetValue().ToString();
                    SalidaDatosColab.NACH2 = lt_E_OUTPUT[3].GetValue().ToString();
                    SalidaDatosColab.JEFE  = lt_E_OUTPUT[10].GetValue().ToString();

                    ListaColaborador.Add(SalidaDatosColab);

                    //for (int i = 0; i < lt_E_OUTPUT.Count(); i++)
                    //{
                    //    SalidaDatosColab = new InformacionColaboradores();
                    //    SalidaDatosColab.VORNA = lt_E_OUTPUT[i].GetValue().ToString();
                    //    SalidaDatosColab.NACHN = lt_E_OUTPUT[i].GetValue().ToString();
                    //    SalidaDatosColab.NACH2 = lt_E_OUTPUT[i].GetValue().ToString();
                    //    ListaColaborador.Add(SalidaDatosColab);
                    //}
                }
 
                return ListaColaborador;
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.Write(e.StackTrace);
                throw new Exception();
            }
            finally
            {
                lt_T_MENSAJE = null;
                SalidaDatosColab = null;
                conexion = null;
            }
        }



        public void ObtenerDatosJerarquia(string RUT, string usuario, string contrasena)
        {
            IRfcTable lt_T_MENSAJE;

            Tablamensaje T_SALIDA;

            IRfcTable lt_T_OUTPUT;

            ColaboradresJerarquia SalidaDatosColabJera;

            ConexionController conexion = new ConexionController();

            List<ColaboradresJerarquia> ListaColaboradorJera = new List<ColaboradresJerarquia>();

            List<Tablamensaje> ListaMensaje = new List<Tablamensaje>();

            string retorno = "ERROR";

            try
            {
                if (!string.IsNullOrEmpty(usuario) && !string.IsNullOrEmpty(contrasena))
                    retorno = conexion.connectionsSAP(usuario, contrasena);

                if (string.IsNullOrEmpty(retorno))
                {
                    RfcDestination SapRfcDestination = RfcDestinationManager.GetDestination(conexion.connectorConfig);
                    RfcRepository SapRfcRepository = SapRfcDestination.Repository;

                    IRfcFunction BapiGetUser = SapRfcRepository.CreateFunction("ZHR_COL_JER");

                        BapiGetUser.SetValue("I_RUT", RUT);

                        BapiGetUser.Invoke(SapRfcDestination);

                        lt_T_OUTPUT = BapiGetUser.GetTable("T_OUTPUT");

                    for (int i = 0; i < lt_T_OUTPUT.RowCount; i++)
                    {
                        SalidaDatosColabJera = new ColaboradresJerarquia();
                        SalidaDatosColabJera.ICNUM = lt_T_OUTPUT[i].GetString("ICNUM");
                        SalidaDatosColabJera.VORNA = lt_T_OUTPUT[i].GetString("VORNA");
                        SalidaDatosColabJera.NACHN = lt_T_OUTPUT[i].GetString("NACHN");
                        SalidaDatosColabJera.NACH2 = lt_T_OUTPUT[i].GetString("NACH2");
                        ObjSalida.Add(SalidaDatosColabJera);
                    }
                      

                    lt_T_MENSAJE = BapiGetUser.GetTable("T_MENSAJE");

                    for (int i = 0; i < lt_T_MENSAJE.RowCount; i++)
                    {
                        T_SALIDA = new Tablamensaje();
                        T_SALIDA.codigo = lt_T_MENSAJE[i].GetString("CODIGO");
                        T_SALIDA.mensaje = lt_T_MENSAJE[i].GetString("MENSAJE");
                        Objmensaje.Add(T_SALIDA);
                    }
                }

            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.Write(e.StackTrace);
                throw new Exception();
            }
            finally
            {
                lt_T_MENSAJE = null;
                SalidaDatosColabJera = null;
                ListaMensaje = null;
                conexion = null;
            }
        }

        public List<T_BINARY> ObtenerLiquidacion(string RUT, string MES, string ANIO, string usuario, string contrasena)
        {
            IRfcTable lt_T_MENSAJE;

            Tablamensaje T_SALIDA;

            IRfcTable  lt_E_T_BINARY;

            T_BINARY SalidaBinaria;

            ConexionController conexion = new ConexionController();

            List<T_BINARY> Listabinaria = new List<T_BINARY>();

            List<Tablamensaje> ListaMensaje = new List<Tablamensaje>();

            string retorno = "ERROR";

            try
            {
                if (!string.IsNullOrEmpty(usuario) && !string.IsNullOrEmpty(contrasena))
                    retorno = conexion.connectionsSAP(usuario, contrasena);

                if (string.IsNullOrEmpty(retorno))
                {
                    RfcDestination SapRfcDestination = RfcDestinationManager.GetDestination(conexion.connectorConfig);
                    RfcRepository SapRfcRepository = SapRfcDestination.Repository;

                    IRfcFunction BapiGetUser = SapRfcRepository.CreateFunction("ZHR_LIQ_SUE");

                    BapiGetUser.SetValue("I_RUT", RUT);
                    BapiGetUser.SetValue("I_MES", MES);
                    BapiGetUser.SetValue("I_ANO", ANIO);


                    BapiGetUser.Invoke(SapRfcDestination);

                    lt_E_T_BINARY = BapiGetUser.GetTable("T_BINARY");

                    Byte[] bytes;


                

                    for (int i = 0; i < lt_E_T_BINARY.Count; i++)
                    {

                        //bytes = (Byte[])lt_E_T_BINARY[i].GetValue(0);
                        //bytes = (Byte[])lt_E_T_BINARY[i].GetValue(0);

                        SalidaBinaria = new T_BINARY();
                        SalidaBinaria.LINE = (Byte[])lt_E_T_BINARY[i].GetValue(0);
                        Listabinaria.Add(SalidaBinaria);
                    }
                  

                    lt_T_MENSAJE = BapiGetUser.GetTable("T_MENSAJE");

                    for (int i = 0; i < lt_T_MENSAJE.RowCount; i++)
                    {
                        T_SALIDA = new Tablamensaje();
                        T_SALIDA.codigo = lt_T_MENSAJE[i].GetString("CODIGO");
                        T_SALIDA.mensaje = lt_T_MENSAJE[i].GetString("MENSAJE");
                        ListaMensaje.Add(T_SALIDA);
                    }
                }

                return Listabinaria;
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.Write(e.StackTrace);
                throw new Exception();
            }
            finally
            {
                lt_T_MENSAJE = null;
                lt_E_T_BINARY = null;
                SalidaBinaria = null;
                ListaMensaje = null;
                conexion = null;
            }
        }



    }
}