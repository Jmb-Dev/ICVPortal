﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoTanner.Models
{
    public class Absentismo
    {
        public string BEGDA { get; set; }
        public string ENDDA { get; set; }
        public string AEDTM { get; set; }
        public string AWART { get; set; }
        public string ABRTG { get; set;}
        public string SPRPS { get; set; }
        public string DOCNR { get; set; }

    }
}
