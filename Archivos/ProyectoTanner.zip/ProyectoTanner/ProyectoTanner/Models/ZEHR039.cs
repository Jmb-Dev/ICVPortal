﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoTanner.Models
{
    public class ListadosolicitudesPendientesAprobacion
    {
        public int SelectedUser { get; set; }
        public string DOCNR { get; set; }
        public string ICNUM { get; set; }
        public string VORNA { get; set; }
        public string NACHN { get; set; }
        public string NACH2 { get; set; }
        public string AEDTM { get; set; }
        public string AWART { get; set; }
        public string ATEXT { get; set; }
        public string BEGDA { get; set; }
        public string ENDDA { get; set; }
        public string ABWTG { get; set; }
        public string SPRPS { get; set; }


        //public List<Tablamensaje> salidaMensajes { get; set; }
    }
}