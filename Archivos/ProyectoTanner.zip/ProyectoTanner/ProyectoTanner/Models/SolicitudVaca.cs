﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoTanner.Models
{
    public class SolicitudVaca
    {
        public string FecDesde { get; set; }
        public string FecHasta { get; set; }
        public string TipoVaca { get; set; }

    }
}