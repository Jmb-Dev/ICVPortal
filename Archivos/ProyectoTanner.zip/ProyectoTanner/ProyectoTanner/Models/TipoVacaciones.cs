﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoTanner.Models
{
    public class TipoVacaciones
    {
        public string COD_TIP { get; set; }
        public string DES_TIP { get; set; }
    }
}