﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoTanner.Models
{
    public class Tablamensaje
    {
        public string codigo { get; set; }
        public string mensaje { get; set; }

}
}