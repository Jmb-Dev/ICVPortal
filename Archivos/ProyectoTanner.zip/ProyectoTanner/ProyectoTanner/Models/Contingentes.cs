﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoTanner.Models
{
    public class Contingentes
    {
        public string ANZHL { get; set; }
        public string KVERB { get; set; }
        public string DISPO { get; set; }
        public string KTART { get; set; }
        public string KTEXT { get; set;
        }
    }
}