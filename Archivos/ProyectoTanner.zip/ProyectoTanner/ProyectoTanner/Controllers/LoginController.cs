﻿using System; 
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProyectoTanner.Services;
using System.Configuration;

namespace ProyectoTanner.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(string name , string password)
        {

            Session["usuarioSap"] = ConfigurationManager.AppSettings["usuario"];
            Session["contrasenaSap"] = ConfigurationManager.AppSettings["password"];

            var InformColaborador = new InformacionColaborador();

            var model = InformColaborador.ObtenerDatos(name, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());

            if (model.Count > 0)
            {
                Session["SessionActiva"] = "X";
                Session["NombreUsuario"] = string.Concat(string.Concat(model[0].VORNA + " " + model[0].NACH2));
                Session["Usuario"] = name;

                if (model[0].JEFE != "") { Session["UsuarioAprobador"] = model[0].JEFE; } else { Session["UsuarioAprobador"] = ""; }

                return RedirectToAction("Index", "Home");
            }

            return View();
        }
    }
}