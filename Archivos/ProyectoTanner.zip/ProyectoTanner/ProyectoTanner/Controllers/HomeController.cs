﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProyectoTanner.Services;
using System.Configuration;
using ProyectoTanner.Models;
using System.Globalization;

namespace ProyectoTanner.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Login(string usuario, string password)
        {
            if (usuario != null && password != null)
            {
                Session["usuarioSap"] = ConfigurationManager.AppSettings["usuario"];
                Session["contrasenaSap"] = ConfigurationManager.AppSettings["password"];

                var InformColaborador = new InformacionColaborador();

                var model = InformColaborador.ObtenerDatos(usuario, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());

                if (model.Count > 0)
                {
                    Session["SessionActiva"] = "X";
                    Session["NombreUsuario"] = string.Concat(string.Concat(model[0].VORNA + " " + model[0].NACH2));
                    Session["Usuario"] = usuario;



                    return RedirectToAction("Index", "Home");
                }
            }
            return View();
        }
        [HttpPost]
        public ActionResult Login(string usuario)
        {
            if (usuario != null)
            {
                Session["usuarioSap"] = ConfigurationManager.AppSettings["usuario"];
                Session["contrasenaSap"] = ConfigurationManager.AppSettings["password"];

                var InformColaborador = new InformacionColaborador();

                var model = InformColaborador.ObtenerDatos(usuario, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());

                if (model.Count > 0)
                {
                    Session["SessionActiva"] = "X";
                    Session["NombreUsuario"] = string.Concat(string.Concat(model[0].VORNA), model[0].NACH2);
                    Session["Usuario"] = usuario;

                    return RedirectToAction("Index", "Home");
                }
            }
            return View();
        }
        public ActionResult LogOut()
        {
            Session["SessionActiva"] = "";
            Session["NombreUsuario"] = "";

            return RedirectToAction("Login", "LOGIN");
            return View();
        }
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult MisSolicitudes()
        {
            string NombreUsuario = (string)(Session["NombreUsuario"]);
            string Usuario = (string)(Session["usuario"]);
            var VacacionesService = new VacacionesService();
            var model = VacacionesService.ObtenerVacacionesHistorico(Usuario, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
            return View(model);
        }

        [HttpGet]
        public ActionResult Solicitud()
        {
            string NombreUsuario = (string)(Session["NombreUsuario"]);
            string Usuario = (string)(Session["usuario"]);
            VacacionesService VacacionesService = new VacacionesService();
            VacacionesService.ObtenerVacaciones(Usuario, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
            ViewBag.Milistado = VacacionesService.ObjSalida;
            ViewBag.Milistado2 = VacacionesService.Objmensaje;
            ViewBag.Milistado3 = VacacionesService.ObjTipo;
            return View();
        }


        [HttpPost]
        public ActionResult Solicitud2(string FecDesde, string FecHasta, string TipoVaca)
        {
            DateTime fechHoy = DateTime.Now;

            string fechadia = Convert.ToString(fechHoy);

            List<SolicitudVacaciones> Solicit = new List<SolicitudVacaciones>();
            SolicitudVacaciones p_Solicit;

            string NombreUsuario = (string)(Session["NombreUsuario"]);
            string Usuario = (string)(Session["usuario"]);
            string Usuario2 = string.Empty;

            var dateTimeFormat = CultureInfo.InvariantCulture.DateTimeFormat;
            var date = DateTime.ParseExact(FecDesde, "dd/MM/yyyy", dateTimeFormat);
            var date2 = DateTime.ParseExact(FecHasta, "dd/MM/yyyy", dateTimeFormat);

            string fech_d = string.Format("{0:d/M/yyyy}", fechadia);

            DateTime fec_1 = Convert.ToDateTime(date);
            DateTime fec_2 = Convert.ToDateTime(date2);
            DateTime fec_3 = Convert.ToDateTime(fech_d);

            VacacionesService SolicitudVaca = new VacacionesService();

            //Llena Estructura 
            p_Solicit = new SolicitudVacaciones();
            p_Solicit.ICNUM1 = Usuario;
            p_Solicit.AEDTM = fec_3.ToString("dd/MM/yyyy");
            p_Solicit.AWART = "7000";
            p_Solicit.BEGDA = fec_1.ToString("dd/MM/yyyy"); ;
            p_Solicit.ENDDA = fec_2.ToString("dd/MM/yyyy"); ;
            p_Solicit.ICNUM2 = Usuario;
            p_Solicit.SPRPS = "X";
            Solicit.Add(p_Solicit);

            if (fec_2 >= fec_1)
            {
                SolicitudVaca.SolictudVacaciones(Solicit, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());

                //ViewBag.Solicitud = SolicitudVaca.Objmensaje;

                if (SolicitudVaca.Objmensaje.Count > 0)
                {
                    for (int i = 0; i < SolicitudVaca.Objmensaje.Count; i++)
                    {
                        ViewBag.Mensaje = SolicitudVaca.Objmensaje[i].mensaje;
                    }

                    ViewBag.Mostrar = true;

                    VacacionesService VacacionesService = new VacacionesService();
                    VacacionesService.ObtenerVacaciones(Usuario, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
                    ViewBag.Milistado = VacacionesService.ObjSalida;
                    ViewBag.Milistado2 = VacacionesService.Objmensaje;
                    ViewBag.Milistado3 = VacacionesService.ObjTipo;               
                }
                else
                {
                    VacacionesService VacacionesService = new VacacionesService();
                    VacacionesService.ObtenerVacaciones(Usuario, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
                    ViewBag.Milistado = VacacionesService.ObjSalida;
                    ViewBag.Milistado2 = VacacionesService.Objmensaje;
                    ViewBag.Milistado3 = VacacionesService.ObjTipo;
                }
            }
            return View("Solicitud");
        }

        [HttpGet]
        public ActionResult MiEquipo(string Mensaje)
        {
            if (Mensaje != null)
            {
                string NombreUsuario = (string)(Session["NombreUsuario"]);
                string Usuario = (string)(Session["usuario"]);
                VacacionesService Aprobaciones = new VacacionesService();
                Aprobaciones.ObtenerListaPendientesAprob(Usuario, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
                ViewBag.MilistadoAProb = Aprobaciones.ObjPendAprob;
                //ViewBag.ListaMensaje = Aprobaciones.ObjSalida;

                ViewBag.Mostrar = true;
                ViewBag.Mensaje = Mensaje;
            }
            else
            {
                string NombreUsuario = (string)(Session["NombreUsuario"]);
                string Usuario = (string)(Session["usuario"]);
                VacacionesService Aprobaciones = new VacacionesService();
                Aprobaciones.ObtenerListaPendientesAprob(Usuario, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
                ViewBag.MilistadoAProb = Aprobaciones.ObjPendAprob;
                //ViewBag.ListaMensaje = Aprobaciones.ObjSalida;
            }

            return View();
        }


        //[HttpPost]
        //public ActionResult MiEquipo(FormCollection collection)
        //{
        //    string NombreUsuario = (string)(Session["NombreUsuario"]);
        //    string Usuario = (string)(Session["usuario"]);
        //    string Colaborador = "137413892";
        //    string Aprueba = "3";
        //    string Rechaza = "4";  
        //    VacacionesService Aprobaciones = new VacacionesService();
        //    string DOCNR = Request.Form["DOCNR"];
        //    string ICNUM = Request.Form["ICNUM"];

        //    Aprobaciones.AprobarRechazarVacaciones(Usuario, Aprueba, DOCNR, Colaborador, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
        //    ViewBag.ListaMensaje = Aprobaciones.Objmensaje;

        //    Aprobaciones.ObtenerListaPendientesAprob(Usuario, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
        //    ViewBag.MilistadoAProb = Aprobaciones.ObjPendAprob;
        //    ViewBag.ListaMensaje = Aprobaciones.ObjSalida;
        //    return View();
        //}

        [HttpGet]
        public ActionResult Aprobar(string Docnr, string Icnum )
        {
            string NombreUsuario = (string)(Session["NombreUsuario"]);
            string Usuario = (string)(Session["usuario"]);
            string Incnu = Icnum.Replace(".","");
            string Colaborador = Incnu.Replace("-", "");
            string Aprueba = "3";

            VacacionesService Aprobaciones = new VacacionesService();

            Aprobaciones.AprobarRechazarVacaciones(Usuario, Aprueba, Docnr, Colaborador, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
            ViewBag.ListaMensaje = Aprobaciones.Objmensaje;
            if (Aprobaciones.Objmensaje.Count > 0)
            {
                for (int i = 0; i < Aprobaciones.Objmensaje.Count; i++)
                {
                    ViewBag.Mensaje = Aprobaciones.Objmensaje[i].mensaje;
                }

                ViewBag.Mostrar = true;
            }
            else
            {
                Aprobaciones.ObtenerListaPendientesAprob(Usuario, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
                ViewBag.MilistadoAProb = Aprobaciones.ObjPendAprob;
                ViewBag.ListaMensaje = Aprobaciones.ObjSalida;
            }

            return RedirectToAction("MiEquipo", "HOME", new { Mensaje = ViewBag.Mensaje });
        }

        [HttpGet]
        public ActionResult Rechazar(string Docnr, string Icnum)
        {
            string NombreUsuario = (string)(Session["NombreUsuario"]);
            string Usuario = (string)(Session["usuario"]);
            string Incnu = Icnum.Replace(".", "");
            string Colaborador = Incnu.Replace("-", "");
            string Rechaza = "4";

            VacacionesService Aprobaciones = new VacacionesService();

            Aprobaciones.AprobarRechazarVacaciones(Usuario, Rechaza, Docnr, Colaborador, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
           // ViewBag.ListaMensaje = Aprobaciones.Objmensaje;

            if (Aprobaciones.Objmensaje.Count > 0)
            {
                for (int i = 0; i < Aprobaciones.Objmensaje.Count; i++)
                {
                    ViewBag.Mensaje = Aprobaciones.Objmensaje[i].mensaje;
                }

                ViewBag.Mostrar = true;
            }
            else
            {
                Aprobaciones.ObtenerListaPendientesAprob(Usuario, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
                ViewBag.MilistadoAProb = Aprobaciones.ObjPendAprob;
                ViewBag.ListaMensaje = Aprobaciones.ObjSalida;
            }
            return RedirectToAction("MiEquipo", "HOME", new { Mensaje = ViewBag.Mensaje });
        }

        public ActionResult VerLiquidacion()
        {
            string NombreUsuario = (string)(Session["NombreUsuario"]);
            string Usuario = (string)(Session["usuario"]);
            var InformColaborador = new InformacionColaborador();
            ViewBag.liquidacion = InformColaborador.ObtenerLiquidacion(Usuario, "04", "2017", Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
            return View();
        }

        [HttpGet]
        public ActionResult SolicitudMiEquipo()
        {
            string NombreUsuario = (string)(Session["NombreUsuario"]);
            string Usuario = (string)(Session["usuario"]);
            InformacionColaborador Colaboradores = new InformacionColaborador();
            Colaboradores.ObtenerDatosJerarquia(Usuario, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());


            ViewBag.ListaColaborades = Colaboradores.ObjSalida;

            for (int i = 0; i < Colaboradores.ObjSalida.Count; i++)
            {
                ViewBag.RutColaborador = Colaboradores.ObjSalida[i].ICNUM;
                ViewBag.NombreColaborador = Colaboradores.ObjSalida[i].VORNA + " " + Colaboradores.ObjSalida[i].NACHN;
            }

            return View();
        }

        [HttpPost]
        public ActionResult SolicitudMiEquipo(string NombreColabor, string RutColabor)
        {
            string NombreUsuario = (string)(Session["NombreUsuario"]);
            string Usuario = (string)(Session["usuario"]);

            InformacionColaborador Colaboradores = new InformacionColaborador();
            Colaboradores.ObtenerDatosJerarquia(Usuario, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());

            ViewBag.ListaColaborades = Colaboradores.ObjSalida;

            for (int i = 0; i < Colaboradores.ObjSalida.Count; i++)
            {
                ViewBag.RutColabor = Colaboradores.ObjSalida[i].ICNUM;
                ViewBag.NombreColabor = Colaboradores.ObjSalida[i].VORNA + " " + Colaboradores.ObjSalida[i].NACHN;
            }

            string Colaborador = ViewBag.RutColabor;

            VacacionesService VacacionesService = new VacacionesService();
            VacacionesService.ObtenerVacaciones(Colaborador, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
            ViewBag.Milistado = VacacionesService.ObjSalida;
            ViewBag.Milistado2 = VacacionesService.Objmensaje;
            ViewBag.Milistado3 = VacacionesService.ObjTipo;
            

            return View("SolicitudMiEquipo2");
           // return RedirectToAction("SolicitudMiEquipo2", "HOME", new { RutColabor = ViewBag.RutColabor, NombreColabor = ViewBag.NombreColabor });
        }

        [HttpGet]
        public ActionResult SolicitudMiEquipo2(string FecDesde, string FecHasta, string TipoVaca, string RutColabor, string NombreColabor)
        {
            // Formateo RUT Colaborador
            string Colaborador = RutColabor.Replace(".", "");
            Colaborador.Replace("-", "");

            if (FecDesde == null)
            {
                string NombreUsuario = (string)(Session["NombreUsuario"]);
                string Usuario = (string)(Session["usuario"]);
                
                VacacionesService VacacionesService = new VacacionesService();
                VacacionesService.ObtenerVacaciones(Colaborador, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
                ViewBag.Milistado = VacacionesService.ObjSalida;
                ViewBag.Milistado2 = VacacionesService.Objmensaje;
                ViewBag.Milistado3 = VacacionesService.ObjTipo;

                ViewBag.NombreColaborador = NombreColabor;
            }
            else
            {
                DateTime fechHoy = DateTime.Now;
                DateTime Hoy;
                string fechadia = Convert.ToString(fechHoy);

                List<SolicitudVacaciones> Solicit = new List<SolicitudVacaciones>();
                SolicitudVacaciones p_Solicit;

                string NombreUsuario = (string)(Session["NombreUsuario"]);
                string Usuario = (string)(Session["usuario"]);

                var dateTimeFormat = CultureInfo.InvariantCulture.DateTimeFormat;
                var date = DateTime.ParseExact(FecDesde, "dd/MM/yyyy", dateTimeFormat);
                var date2 = DateTime.ParseExact(FecHasta, "dd/MM/yyyy", dateTimeFormat);

                string fech_d = string.Format("{0:d/M/yyyy}", fechadia);


                DateTime fec_1 = Convert.ToDateTime(date);
                DateTime fec_2 = Convert.ToDateTime(date2);
                DateTime fec_3 = Convert.ToDateTime(fech_d);

                VacacionesService SolicitudVaca = new VacacionesService();

                //Llena Estructura 
                p_Solicit = new SolicitudVacaciones();
                p_Solicit.ICNUM1 = Usuario;
                p_Solicit.AEDTM = fec_3.ToString("dd/MM/yyyy");
                p_Solicit.AWART = "7000";
                p_Solicit.BEGDA = fec_1.ToString("dd/MM/yyyy"); ;
                p_Solicit.ENDDA = fec_2.ToString("dd/MM/yyyy"); ;
                p_Solicit.ICNUM2 = Colaborador;
                p_Solicit.SPRPS = "X";
                Solicit.Add(p_Solicit);

                if (fec_2 >= fec_1)
                {
                    SolicitudVaca.SolictudVacaciones(Solicit, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
                    ViewBag.Solicitud = SolicitudVaca.Objmensaje;

                    ViewBag.Mostrar = true;

                    VacacionesService VacacionesService = new VacacionesService();
                    VacacionesService.ObtenerVacaciones(RutColabor, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
                    ViewBag.Milistado = VacacionesService.ObjSalida;
                    ViewBag.Milistado2 = VacacionesService.Objmensaje;
                    ViewBag.Milistado3 = VacacionesService.ObjTipo;
                }
            }
            return View();
        }

        [HttpPost]
        public ActionResult SolicitudMiEquipo2(string FecDesde, string FecHasta, string RutColabor, string NombreColabor)
        {
           
            DateTime fechHoy = DateTime.Now;
            DateTime Hoy;
            string fechadia = Convert.ToString(fechHoy);

            // Formateo RUT Colaborador
            string Colaborador = RutColabor.Replace(".", "");
            Colaborador.Replace("-", "");

            List<SolicitudVacaciones> Solicit = new List<SolicitudVacaciones>();
            SolicitudVacaciones p_Solicit;

            string NombreUsuario = (string)(Session["NombreUsuario"]);
            string Usuario = (string)(Session["usuario"]);

            string Usuario2 = string.Empty;

            var dateTimeFormat = CultureInfo.InvariantCulture.DateTimeFormat;
            var date = DateTime.ParseExact(FecDesde, "dd/MM/yyyy", dateTimeFormat);
            var date2 = DateTime.ParseExact(FecHasta, "dd/MM/yyyy", dateTimeFormat);

            string fech_d = string.Format("{0:d/M/yyyy}", fechadia);


            DateTime fec_1 = Convert.ToDateTime(date);
            DateTime fec_2 = Convert.ToDateTime(date2);
            DateTime fec_3 = Convert.ToDateTime(fech_d);

            VacacionesService SolicitudVaca = new VacacionesService();

            //Llena Estructura 
            p_Solicit = new SolicitudVacaciones();
            p_Solicit.ICNUM1 = Usuario;
            p_Solicit.AEDTM = fec_3.ToString("dd/MM/yyyy");
            p_Solicit.AWART = "7000";
            p_Solicit.BEGDA = fec_1.ToString("dd/MM/yyyy"); ;
            p_Solicit.ENDDA = fec_2.ToString("dd/MM/yyyy"); ;
            p_Solicit.ICNUM2 = Colaborador;
            p_Solicit.SPRPS = "X";
            Solicit.Add(p_Solicit);

            if (fec_2 >= fec_1)
            {
                SolicitudVaca.SolictudVacaciones(Solicit, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
                ViewBag.Solicitud = SolicitudVaca.Objmensaje;
            }
            if (SolicitudVaca.Objmensaje.Count > 0)
            {
                for (int i = 0; i < SolicitudVaca.Objmensaje.Count; i++)
                {
                    ViewBag.Mensaje = SolicitudVaca.Objmensaje[i].mensaje;
                }

                ViewBag.Mostrar = true;

                ViewBag.NombreColabor = NombreColabor;

                VacacionesService VacacionesService = new VacacionesService();
                VacacionesService.ObtenerVacaciones(RutColabor, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
                ViewBag.Milistado = VacacionesService.ObjSalida;
                ViewBag.Milistado2 = VacacionesService.Objmensaje;
                ViewBag.Milistado3 = VacacionesService.ObjTipo;
            }
            else
            {
                ViewBag.NombreColabor = NombreColabor;

                VacacionesService VacacionesService = new VacacionesService();
                VacacionesService.ObtenerVacaciones(RutColabor, Session["usuarioSap"].ToString(), Session["contrasenaSap"].ToString());
                ViewBag.Milistado = VacacionesService.ObjSalida;
                ViewBag.Milistado2 = VacacionesService.Objmensaje;
                ViewBag.Milistado3 = VacacionesService.ObjTipo;
            }       

            return View();
        }
    }
  }